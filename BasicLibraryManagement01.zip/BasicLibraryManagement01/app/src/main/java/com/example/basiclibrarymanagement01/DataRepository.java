package com.example.basiclibrarymanagement01;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class DataRepository {

    private SQLiteDatabase db;

    public DataRepository(Context context) {
        DatabaseHelper dbHelper = new DatabaseHelper(context);
        db = dbHelper.getWritableDatabase();
    }

    // CRUD operations for Book

    // Method to add a book to the database
    public long addBook(Book book) {
        ContentValues values = new ContentValues();
        values.put("BOOK_ID", book.getId());
        values.put("TITLE", book.getTitle());
        values.put("PUBLISHER_NAME", book.getPublisherName());
        return db.insert("Book", null, values);
    }

    // Method to get all books from the database
    public List<Book> getAllBooks() {
        List<Book> books = new ArrayList<>();
        Cursor cursor = db.query("Book", null, null, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            int idIndex = cursor.getColumnIndex("BOOK_ID");
            int titleIndex = cursor.getColumnIndex("TITLE");
            int publisherIndex = cursor.getColumnIndex("PUBLISHER_NAME");

            do {
                if (idIndex != -1 && titleIndex != -1 && publisherIndex != -1) {
                    String id = cursor.getString(idIndex);
                    String title = cursor.getString(titleIndex);
                    String publisherName = cursor.getString(publisherIndex);
                    Book book = new Book(id, title, publisherName);
                    books.add(book);
                }
            } while (cursor.moveToNext());
            cursor.close();
        }
        return books;
    }

    // Method to update a book in the database
    public int updateBook(Book book) {
        ContentValues values = new ContentValues();
        values.put("TITLE", book.getTitle());
        values.put("PUBLISHER_NAME", book.getPublisherName());
        return db.update("Book", values, "BOOK_ID = ?", new String[]{book.getId()});
    }

    // Method to delete a book from the database
    public int deleteBook(String bookId) {
        return db.delete("Book", "BOOK_ID = ?", new String[]{bookId});
    }

// Publisher

    public long addPublisher(Publisher publisher) {
        ContentValues values = new ContentValues();
        values.put("NAME", publisher.getName());
        values.put("ADDRESS", publisher.getAddress());
        values.put("PHONE", publisher.getPhone());
        return db.insert("Publisher", null, values);
    }

    public List<Publisher> getAllPublishers() {
        List<Publisher> publishers = new ArrayList<>();
        Cursor cursor = db.query("Publisher", null, null, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            int nameIndex = cursor.getColumnIndex("NAME");
            int addressIndex = cursor.getColumnIndex("ADDRESS");
            int phoneIndex = cursor.getColumnIndex("PHONE");

            do {
                if (nameIndex != -1 && addressIndex != -1 && phoneIndex != -1) {
                    String name = cursor.getString(nameIndex);
                    String address = cursor.getString(addressIndex);
                    String phone = cursor.getString(phoneIndex);
                    Publisher publisher = new Publisher(name, address, phone);
                    publishers.add(publisher);
                }
            } while (cursor.moveToNext());
            cursor.close();
        }
        return publishers;
    }

    public int updatePublisher(Publisher publisher) {
        ContentValues values = new ContentValues();
        values.put("ADDRESS", publisher.getAddress());
        values.put("PHONE", publisher.getPhone());
        return db.update("Publisher", values, "NAME = ?", new String[]{publisher.getName()});
    }

    public int deletePublisher(String name) {
        return db.delete("Publisher", "NAME = ?", new String[]{name});
    }

// Branch

    public long addBranch(Branch branch) {
        ContentValues values = new ContentValues();
        values.put("BRANCH_ID", branch.getId());
        values.put("BRANCH_NAME", branch.getName());
        values.put("ADDRESS", branch.getAddress());
        return db.insert("Branch", null, values);
    }

    public List<Branch> getAllBranches() {
        List<Branch> branches = new ArrayList<>();
        Cursor cursor = db.query("Branch", null, null, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            int idIndex = cursor.getColumnIndex("BRANCH_ID");
            int nameIndex = cursor.getColumnIndex("BRANCH_NAME");
            int addressIndex = cursor.getColumnIndex("ADDRESS");

            do {
                if (idIndex != -1 && nameIndex != -1 && addressIndex != -1) {
                    String id = cursor.getString(idIndex);
                    String name = cursor.getString(nameIndex);
                    String address = cursor.getString(addressIndex);
                    Branch branch = new Branch(id, name, address);
                    branches.add(branch);
                }
            } while (cursor.moveToNext());
            cursor.close();
        }
        return branches;
    }

    public int updateBranch(Branch branch) {
        ContentValues values = new ContentValues();
        values.put("BRANCH_NAME", branch.getName());
        values.put("ADDRESS", branch.getAddress());
        return db.update("Branch", values, "BRANCH_ID = ?", new String[]{branch.getId()});
    }

    public int deleteBranch(String branchId) {
        return db.delete("Branch", "BRANCH_ID = ?", new String[]{branchId});
    }

// Member

    public long addMember(Member member) {
        ContentValues values = new ContentValues();
        values.put("CARD_NO", member.getCardNo());
        values.put("NAME", member.getName());
        values.put("ADDRESS", member.getAddress());
        values.put("PHONE", member.getPhone());
        values.put("UNPAID_DUES", member.getUnpaidDues());
        return db.insert("Member", null, values);
    }

    public List<Member> getAllMembers() {
        List<Member> members = new ArrayList<>();
        Cursor cursor = db.query("Member", null, null, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            int cardNoIndex = cursor.getColumnIndex("CARD_NO");
            int nameIndex = cursor.getColumnIndex("NAME");
            int addressIndex = cursor.getColumnIndex("ADDRESS");
            int phoneIndex = cursor.getColumnIndex("PHONE");
            int duesIndex = cursor.getColumnIndex("UNPAID_DUES");

            do {
                if (cardNoIndex != -1 && nameIndex != -1 && addressIndex != -1 && phoneIndex != -1 && duesIndex != -1) {
                    String cardNo = cursor.getString(cardNoIndex);
                    String name = cursor.getString(nameIndex);
                    String address = cursor.getString(addressIndex);
                    String phone = cursor.getString(phoneIndex);
                    double dues = cursor.getDouble(duesIndex);
                    Member member = new Member(cardNo, name, address, phone, dues);
                    members.add(member);
                }
            } while (cursor.moveToNext());
            cursor.close();
        }
        return members;
    }

    public int updateMember(Member member) {
        ContentValues values = new ContentValues();
        values.put("NAME", member.getName());
        values.put("ADDRESS", member.getAddress());
        values.put("PHONE", member.getPhone());
        values.put("UNPAID_DUES", member.getUnpaidDues());
        return db.update("Member", values, "CARD_NO = ?", new String[]{member.getCardNo()});
    }

    public int deleteMember(String cardNo) {
        return db.delete("Member", "CARD_NO = ?", new String[]{cardNo});
    }

    // BookAuthor

    public long addBookAuthor(BookAuthor bookAuthor) {
        ContentValues values = new ContentValues();
        values.put("BOOK_ID", bookAuthor.getBookId());
        values.put("AUTHOR_NAME", bookAuthor.getAuthorName());
        return db.insert("Book_Author", null, values);
    }

    public List<BookAuthor> getAllBookAuthors() {
        List<BookAuthor> bookAuthors = new ArrayList<>();
        Cursor cursor = db.query("Book_Author", null, null, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            int bookIdIndex = cursor.getColumnIndex("BOOK_ID");
            int authorNameIndex = cursor.getColumnIndex("AUTHOR_NAME");

            do {
                if (bookIdIndex != -1 && authorNameIndex != -1) {
                    String bookId = cursor.getString(bookIdIndex);
                    String authorName = cursor.getString(authorNameIndex);
                    BookAuthor bookAuthor = new BookAuthor(bookId, authorName);
                    bookAuthors.add(bookAuthor);
                }
            } while (cursor.moveToNext());
            cursor.close();
        }
        return bookAuthors;
    }

    public int updateBookAuthor(BookAuthor bookAuthor) {
        ContentValues values = new ContentValues();
        values.put("AUTHOR_NAME", bookAuthor.getAuthorName());
        return db.update("Book_Author", values, "BOOK_ID = ?", new String[]{bookAuthor.getBookId()});
    }

    public int deleteBookAuthor(String bookId, String authorName) {
        return db.delete("Book_Author", "BOOK_ID = ? AND AUTHOR_NAME = ?", new String[]{bookId, authorName});
    }

// BookCopy

    public long addBookCopy(BookCopy bookCopy) {
        ContentValues values = new ContentValues();
        values.put("BOOK_ID", bookCopy.getBookId());
        values.put("BRANCH_ID", bookCopy.getBranchId());
        values.put("ACCESS_NO", bookCopy.getAccessNo());
        return db.insert("Book_Copy", null, values);
    }

    public List<BookCopy> getAllBookCopies() {
        List<BookCopy> bookCopies = new ArrayList<>();
        Cursor cursor = db.query("Book_Copy", null, null, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            int bookIdIndex = cursor.getColumnIndex("BOOK_ID");
            int branchIdIndex = cursor.getColumnIndex("BRANCH_ID");
            int accessNoIndex = cursor.getColumnIndex("ACCESS_NO");

            do {
                if (bookIdIndex != -1 && branchIdIndex != -1 && accessNoIndex != -1) {
                    String bookId = cursor.getString(bookIdIndex);
                    String branchId = cursor.getString(branchIdIndex);
                    String accessNo = cursor.getString(accessNoIndex);
                    BookCopy bookCopy = new BookCopy(bookId, branchId, accessNo);
                    bookCopies.add(bookCopy);
                }
            } while (cursor.moveToNext());
            cursor.close();
        }
        return bookCopies;
    }

    public int updateBookCopy(BookCopy bookCopy) {
        ContentValues values = new ContentValues();
        values.put("BRANCH_ID", bookCopy.getBranchId());
        return db.update("Book_Copy", values, "BOOK_ID = ? AND ACCESS_NO = ?",
                new String[]{bookCopy.getBookId(), bookCopy.getAccessNo()});
    }

    public int deleteBookCopy(String bookId, String accessNo) {
        return db.delete("Book_Copy", "BOOK_ID = ? AND ACCESS_NO = ?", new String[]{bookId, accessNo});
    }

// BookLoan

    // Method to add a book loan to the database
    public long addBookLoan(BookLoan bookLoan) {
        ContentValues values = new ContentValues();
        values.put("ACCESS_NO", bookLoan.getAccessNo());
        values.put("BRANCH_ID", bookLoan.getBranchId());
        values.put("CARD_NO", bookLoan.getCardNo());
        values.put("DATE_OUT", bookLoan.getDateOut());
        values.put("DATE_DUE", bookLoan.getDateDue());
        values.put("DATE_RETURNED", bookLoan.getDateReturned());
        return db.insert("Book_Loan", null, values);
    }

    // Method to get all book loans from the database
    public List<BookLoan> getAllBookLoans() {
        List<BookLoan> bookLoans = new ArrayList<>();
        Cursor cursor = db.query("Book_Loan", null, null, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            int accessNoIndex = cursor.getColumnIndex("ACCESS_NO");
            int branchIdIndex = cursor.getColumnIndex("BRANCH_ID");
            int cardNoIndex = cursor.getColumnIndex("CARD_NO");
            int dateOutIndex = cursor.getColumnIndex("DATE_OUT");
            int dateDueIndex = cursor.getColumnIndex("DATE_DUE");
            int dateReturnedIndex = cursor.getColumnIndex("DATE_RETURNED");

            do {
                if (accessNoIndex != -1 && branchIdIndex != -1 && cardNoIndex != -1 &&
                        dateOutIndex != -1 && dateDueIndex != -1 && dateReturnedIndex != -1) {
                    String accessNo = cursor.getString(accessNoIndex);
                    String branchId = cursor.getString(branchIdIndex);
                    String cardNo = cursor.getString(cardNoIndex);
                    String dateOut = cursor.getString(dateOutIndex);
                    String dateDue = cursor.getString(dateDueIndex);
                    String dateReturned = cursor.getString(dateReturnedIndex);
                    BookLoan bookLoan = new BookLoan(accessNo, branchId, cardNo, dateOut, dateDue, dateReturned);
                    bookLoans.add(bookLoan);
                }
            } while (cursor.moveToNext());
            cursor.close();
        }
        return bookLoans;
    }

    // Method to update a book loan in the database
    public int updateBookLoan(BookLoan bookLoan) {
        ContentValues values = new ContentValues();
        values.put("BRANCH_ID", bookLoan.getBranchId());
        values.put("CARD_NO", bookLoan.getCardNo());
        values.put("DATE_OUT", bookLoan.getDateOut());
        values.put("DATE_DUE", bookLoan.getDateDue());
        values.put("DATE_RETURNED", bookLoan.getDateReturned());
        return db.update("Book_Loan", values, "ACCESS_NO = ?", new String[]{bookLoan.getAccessNo()});
    }

    // Method to delete a book loan from the database
    public int deleteBookLoan(String accessNo) {
        return db.delete("Book_Loan", "ACCESS_NO = ?", new String[]{accessNo});
    }

}
