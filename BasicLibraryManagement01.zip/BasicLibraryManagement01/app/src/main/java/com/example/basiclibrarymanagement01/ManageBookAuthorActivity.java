package com.example.basiclibrarymanagement01;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class ManageBookAuthorActivity extends AppCompatActivity {

    private DataRepository dataRepository;
    private EditText editTextBookId, editTextAuthorName;
    private ListView listViewBookAuthors;
    private ArrayAdapter<BookAuthor> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_book_author);

        dataRepository = new DataRepository(this);

        editTextBookId = findViewById(R.id.editTextBookId);
        editTextAuthorName = findViewById(R.id.editTextAuthorName);


        Button btnAddBookAuthor = findViewById(R.id.btnAddBookAuthor);
        Button btnGetAllBookAuthors = findViewById(R.id.btnGetAllBookAuthors);
        Button btnUpdateBookAuthor = findViewById(R.id.btnUpdateBookAuthor);
        Button btnDeleteBookAuthor = findViewById(R.id.btnDeleteBookAuthor);

        btnAddBookAuthor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add a book author
                String bookId = editTextBookId.getText().toString().trim();
                String authorName = editTextAuthorName.getText().toString().trim();
                BookAuthor bookAuthor = new BookAuthor(bookId, authorName);
                long result = dataRepository.addBookAuthor(bookAuthor);
                if (result != -1) {
                    Toast.makeText(ManageBookAuthorActivity.this, "Book author added successfully", Toast.LENGTH_SHORT).show();
                    refreshBookAuthorList();
                } else {
                    Toast.makeText(ManageBookAuthorActivity.this, "Failed to add book author", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnGetAllBookAuthors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listViewBookAuthors = findViewById(R.id.listViewBookAuthors);
                refreshBookAuthorList();
            }
        });

        btnUpdateBookAuthor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Update a book author
                String bookId = editTextBookId.getText().toString().trim();
                String updatedAuthorName = editTextAuthorName.getText().toString().trim();
                BookAuthor bookAuthor = new BookAuthor(bookId, updatedAuthorName);
                int result = dataRepository.updateBookAuthor(bookAuthor);
                if (result > 0) {
                    Toast.makeText(ManageBookAuthorActivity.this, "Book author updated successfully", Toast.LENGTH_SHORT).show();
                    refreshBookAuthorList();
                } else {
                    Toast.makeText(ManageBookAuthorActivity.this, "Failed to update book author", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnDeleteBookAuthor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Delete a book author
                String bookId = editTextBookId.getText().toString().trim();
                String authorName = editTextAuthorName.getText().toString().trim();
                int result = dataRepository.deleteBookAuthor(bookId, authorName);
                if (result > 0) {
                    Toast.makeText(ManageBookAuthorActivity.this, "Book author deleted successfully", Toast.LENGTH_SHORT).show();
                    refreshBookAuthorList();
                } else {
                    Toast.makeText(ManageBookAuthorActivity.this, "Failed to delete book author", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void refreshBookAuthorList() {
        List<BookAuthor> bookAuthors = dataRepository.getAllBookAuthors();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, bookAuthors);
        listViewBookAuthors.setAdapter(adapter);
    }
}
