package com.example.basiclibrarymanagement01;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class ManageBookCopyActivity extends AppCompatActivity {

    private DataRepository dataRepository;
    private EditText editTextBookId, editTextBranchId, editTextAccessNo;
    private ListView listViewBookCopies;
    private ArrayAdapter<BookCopy> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_book_copy);

        dataRepository = new DataRepository(this);

        editTextBookId = findViewById(R.id.editTextBookId);
        editTextBranchId = findViewById(R.id.editTextBranchId);
        editTextAccessNo = findViewById(R.id.editTextAccessNo);

        Button btnAddBookCopy = findViewById(R.id.btnAddBookCopy);
        Button btnGetAllBookCopies = findViewById(R.id.btnGetAllBookCopies);
        Button btnUpdateBookCopy = findViewById(R.id.btnUpdateBookCopy);
        Button btnDeleteBookCopy = findViewById(R.id.btnDeleteBookCopy);



        btnAddBookCopy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add a book copy
                String bookId = editTextBookId.getText().toString().trim();
                String branchId = editTextBranchId.getText().toString().trim();
                String accessNo = editTextAccessNo.getText().toString().trim();

                if (!bookId.isEmpty() && !branchId.isEmpty() && !accessNo.isEmpty()) {
                    BookCopy bookCopy = new BookCopy(bookId, branchId, accessNo);
                    long result = dataRepository.addBookCopy(bookCopy);
                    if (result != -1) {
                        Toast.makeText(ManageBookCopyActivity.this, "Book copy added successfully", Toast.LENGTH_SHORT).show();
                        refreshBookCopyList();
                    } else {
                        Toast.makeText(ManageBookCopyActivity.this, "Failed to add book copy", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ManageBookCopyActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnGetAllBookCopies.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listViewBookCopies = findViewById(R.id.listViewBookCopies);
                refreshBookCopyList();
            }
        });

        btnUpdateBookCopy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Update a book copy
                String bookId = editTextBookId.getText().toString().trim();
                String branchId = editTextBranchId.getText().toString().trim();
                String accessNo = editTextAccessNo.getText().toString().trim();

                if (!bookId.isEmpty() && !branchId.isEmpty() && !accessNo.isEmpty()) {
                    BookCopy bookCopy = new BookCopy(bookId, branchId, accessNo);
                    int result = dataRepository.updateBookCopy(bookCopy);
                    if (result > 0) {
                        Toast.makeText(ManageBookCopyActivity.this, "Book copy updated successfully", Toast.LENGTH_SHORT).show();
                        refreshBookCopyList();
                    } else {
                        Toast.makeText(ManageBookCopyActivity.this, "Failed to update book copy", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ManageBookCopyActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnDeleteBookCopy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Delete a book copy
                String accessNo = editTextAccessNo.getText().toString().trim();
                String branchId = editTextBranchId.getText().toString().trim();

                if (!accessNo.isEmpty() && !branchId.isEmpty()) {
                    int result = dataRepository.deleteBookCopy(accessNo, branchId);
                    if (result > 0) {
                        Toast.makeText(ManageBookCopyActivity.this, "Book copy deleted successfully", Toast.LENGTH_SHORT).show();
                        refreshBookCopyList();
                    } else {
                        Toast.makeText(ManageBookCopyActivity.this, "Failed to delete book copy", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ManageBookCopyActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void refreshBookCopyList() {
        List<BookCopy> bookCopies = dataRepository.getAllBookCopies();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, bookCopies);
        listViewBookCopies.setAdapter(adapter);
    }
}
