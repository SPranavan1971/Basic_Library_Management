package com.example.basiclibrarymanagement01;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class ManageMemberActivity extends AppCompatActivity {

    private DataRepository dataRepository;
    private EditText editTextCardNo, editTextName, editTextAddress, editTextPhone, editTextUnpaidDues;
    private ListView listViewMembers;
    private ArrayAdapter<Member> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_member);

        dataRepository = new DataRepository(this);

        editTextCardNo = findViewById(R.id.editTextCardNo);
        editTextName = findViewById(R.id.editTextName);
        editTextAddress = findViewById(R.id.editTextAddress);
        editTextPhone = findViewById(R.id.editTextPhone);
        editTextUnpaidDues = findViewById(R.id.editTextUnpaidDues);


        Button btnAddMember = findViewById(R.id.btnAddMember);
        Button btnGetAllMembers = findViewById(R.id.btnGetAllMembers);
        Button btnUpdateMember = findViewById(R.id.btnUpdateMember);
        Button btnDeleteMember = findViewById(R.id.btnDeleteMember);

        btnAddMember.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add a member
                String cardNo = editTextCardNo.getText().toString().trim();
                String name = editTextName.getText().toString().trim();
                String address = editTextAddress.getText().toString().trim();
                String phone = editTextPhone.getText().toString().trim();
                double unpaidDues = Double.parseDouble(editTextUnpaidDues.getText().toString().trim());

                if (!cardNo.isEmpty() && !name.isEmpty() && !address.isEmpty() && !phone.isEmpty()) {
                    Member member = new Member(cardNo, name, address, phone, unpaidDues);
                    long addMemberResult = dataRepository.addMember(member);
                    // Handle result as needed
                    if (addMemberResult != -1) {
                        Toast.makeText(ManageMemberActivity.this, "Member added successfully", Toast.LENGTH_SHORT).show();
                        refreshMemberList();
                    } else {
                        Toast.makeText(ManageMemberActivity.this, "Failed to add member", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ManageMemberActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnGetAllMembers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listViewMembers = findViewById(R.id.listViewMembers);
                refreshMemberList();
            }
        });

        btnUpdateMember.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Update a member
                String cardNo = editTextCardNo.getText().toString().trim();
                String name = editTextName.getText().toString().trim();
                String address = editTextAddress.getText().toString().trim();
                String phone = editTextPhone.getText().toString().trim();
                double unpaidDues = Double.parseDouble(editTextUnpaidDues.getText().toString().trim());

                if (!cardNo.isEmpty() && !name.isEmpty() && !address.isEmpty() && !phone.isEmpty()) {
                    Member updatedMember = new Member(cardNo, name, address, phone, unpaidDues);
                    int updateResult = dataRepository.updateMember(updatedMember);
                    // Handle updateResult as needed
                    if (updateResult > 0) {
                        Toast.makeText(ManageMemberActivity.this, "Member updated successfully", Toast.LENGTH_SHORT).show();
                        refreshMemberList();
                    } else {
                        Toast.makeText(ManageMemberActivity.this, "Failed to update member", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ManageMemberActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnDeleteMember.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Delete a member
                String cardNoToDelete = editTextCardNo.getText().toString().trim();
                if (!cardNoToDelete.isEmpty()) {
                    int deleteResult = dataRepository.deleteMember(cardNoToDelete);
                    // Handle deleteResult as needed
                    if (deleteResult > 0) {
                        Toast.makeText(ManageMemberActivity.this, "Member deleted successfully", Toast.LENGTH_SHORT).show();
                        refreshMemberList();
                    } else {
                        Toast.makeText(ManageMemberActivity.this, "Failed to delete member", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ManageMemberActivity.this, "Please enter card number", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void refreshMemberList() {
        List<Member> members = dataRepository.getAllMembers();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, members);
        listViewMembers.setAdapter(adapter);
    }
}
